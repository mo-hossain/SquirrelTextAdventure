﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;

public class TextController : MonoBehaviour {

    public Text text;

    // List the possible states for this game.
    private enum States { begin, ground, ground_1, branch_dead, branch_dead_1, branch_thin, branch_thin_1, trunk_miss, trunk_0, trunk_1, branch_laden, angry, fight, full, dead }

    private States myState;

    // Use this for initialization
    void Start() {
        text.text = "Are you a squirrel?";
        myState = States.begin;
    }

    // Update is called once per frame
    void Update() {
        print(myState);
        if (myState == States.begin)                 { state_begin(); }
        else if (myState == States.ground)           { state_ground(); }
        else if (myState == States.ground_1)         { state_ground1(); }
        else if (myState == States.branch_dead)      { state_branch_dead(); }
        else if (myState == States.branch_dead_1)    { state_branch_dead1(); }
        else if (myState == States.branch_thin)      { state_branch_thin(); }
        else if (myState == States.branch_thin_1)    { state_branch_thin1(); }
        else if (myState == States.trunk_miss)       { state_trunk_miss(); }
        else if (myState == States.trunk_0)          { state_trunk0(); }
        else if (myState == States.trunk_1)          { state_trunk1(); }
        else if (myState == States.branch_laden)     { state_branch_laden(); }
        else if (myState == States.angry)            { state_angry(); }
        else if (myState == States.fight)            { state_fight(); }
        else if (myState == States.full)             { state_full(); }
        else if (myState == States.dead)             { state_dead(); }
    }

    void state_begin()
    {
        text.text = "You are a hungry squirrel and need to look for food to surive. To save this squirrel through its journey please press S";

        if (Input.GetKeyDown(KeyCode.S)) { myState = States.ground; }
    }

    void state_ground()
    {
          text.text =  "You're sitting at the foot of an oak tree. "
           + "You can see if it has acorns, but you don't know the way. \n \n"
           + "Press Left arrow for the left branch, Right arrow for the right branch,"
           + " Up Arrow for the center.";

        if (Input.GetKeyDown(KeyCode.LeftArrow)) { myState = States.branch_dead; }
        else if (Input.GetKeyDown(KeyCode.RightArrow)) { myState = States.branch_thin; }
        else if (Input.GetKeyDown(KeyCode.UpArrow)) { myState = States.trunk_miss; }
    }

    void state_ground1()
    {
        text.text = "You eat the acorn and return to the ground. With replenished energy you can't wait to find more. \n \n"
            + "Press Left arrow for the left branch, Right arrow for the right branch, "
           + "Up Arrow for the center.";
        if (Input.GetKeyDown(KeyCode.LeftArrow)) { myState = States.branch_dead_1; }
        else if (Input.GetKeyDown(KeyCode.RightArrow)) { myState = States.branch_thin_1; }
        else if (Input.GetKeyDown(KeyCode.UpArrow)) { myState = States.trunk_0; }
    }

    void state_branch_dead()
    {
        text.text = "As you scramble up the left branch, you see there are no leaves, and no acorns here. \n" 
            + "With the wind picking up on this dead branch shouldn't move any more forward! \n \n"
            + "Press Down Arrow to get back now!";
        if (Input.GetKeyDown(KeyCode.DownArrow)) { myState = States.ground; }
        else if (Input.GetKeyDown(KeyCode.UpArrow)) { myState = States.dead; }
    }

    void state_branch_dead1()
    {
        text.text = "As you scramble up the left branch, you see there are no leaves, and no acorns here. \n"
           + "With the wind picking up on this dead branch you should't move any more forward! \n \n"
           + "Press Down Arrow to get back now!";
        if (Input.GetKeyDown(KeyCode.DownArrow)) { myState = States.ground_1; }
        else if (Input.GetKeyDown(KeyCode.UpArrow)) { myState = States.dead; }
    }

    void state_branch_thin()
    {
        text.text = "As you scramble up with the right branch, you discover that it's a thin branch. "
            + "It's not so sturdy up here but theres one acorn up ahead if you dare take it. \n \n"
            + "Press T to take the acorn or press Down Arrow if your too scared.";
        if(Input.GetKeyDown(KeyCode.T)) { myState = States.ground_1; }
        else if (Input.GetKeyDown(KeyCode.DownArrow)) { myState = States.ground; }
    }

    void state_branch_thin1()
    {
        text.text = "You are on a super thin branch. There are no more acorns here and I wouldn't recommend moving any more forward. \n \n"
            + "Press Down Arrow key to come back";
        if (Input.GetKeyDown(KeyCode.DownArrow)) { myState = States.ground_1; }
        else if (Input.GetKeyDown(KeyCode.UpArrow)) { myState = States.dead; }
    }

    void state_trunk_miss()
    {
        text.text = "Your stomach is rumbling and you feel you should eat first then go. \n \n"
            + "Press Down Arrow to come back and look for an acorn.";
        if (Input.GetKeyDown(KeyCode.DownArrow)) { myState = States.ground; }
    }

    void state_trunk0()
    {
        text.text = "You have finally reached the central trunk of the tree! \n \n"
            + "Press Up Arrow to keep going.";
        if (Input.GetKeyDown(KeyCode.UpArrow)) { myState = States.trunk_1; }
    }

    void state_trunk1()
    {
        text.text = "The central trunk of the tree narrows a bit, "
            + "and you discover a hollowed out place where an old branch has dropped off. "
            + "A perfect spot to hide acorns! \n"
            + "The tree's branches form a large V here. \n \n"
            + "Press Left Arrow for the left branch, Right arrow for the right branch.";
        if (Input.GetKeyDown(KeyCode.LeftArrow))       { myState = States.branch_laden; }
        else if (Input.GetKeyDown(KeyCode.RightArrow)) { myState = States.angry; }
    }

    void state_branch_laden()
    {
        text.text = "This sturdy branch has the fricken motherload! "
            + "You can easily live through the rough winter with all these acorns. \n \n"
            + "Press C to collect acorns or Down Arrow to come back to the hollow point.";
        if (Input.GetKeyDown(KeyCode.C))                { myState = States.full; }
        else if (Input.GetKeyDown(KeyCode.DownArrow))   { myState = States.trunk_1; }
    }

    void state_angry()
    {
        text.text = "You see an acorn in front of you. "
            + "But charging at you is a mad squirrel that doesn't want to lose its food! \n \n"
            + "Press F to try and fight this MAD quirrel. \n"
            + "Or press Down Arrow to come back and hide in the hollow spot.";
            if (Input.GetKeyDown(KeyCode.F))                { myState = States.fight; }
            else if (Input.GetKeyDown(KeyCode.RightArrow))  { myState = States.trunk_1; }
        }

    void state_fight()
    {
        text.text = "You charge at the squirrel, showing no fear. "
            + "The mad squirrel see's that you are too brave and charges at you harder! \n \n"
            + "Press R to see the results of the fight.";
        if (Input.GetKeyDown(KeyCode.R)) { myState = States.dead; }
    }

    void state_full()
    {
        text.text = "You did it! \n" 
            + "You saved this squirrel's life. He has enough acorns and live through the winter. \n \n" 
            + "If you wish to play again press P \n \n"
            + "If not press E to end the game.";
        if (Input.GetKeyDown(KeyCode.P))        { myState = States.begin; }
        else if (Input.GetKeyDown(KeyCode.E))   { EditorApplication.isPlaying = false; }
    }

    void state_dead()
    {
        text.text = "Oh no your squirrel went to squirrel heaven! \n" +
            "Press R to restart this game and try to save his life again!";
        if (Input.GetKeyDown(KeyCode.R)) { myState = States.begin; }
    }
}
